# Swayam Digital — AI Voice Trainer Intern Program

A responsive, static landing page for the live DigiSwayam AI Voice Trainer Intern Program.

## Preview locally

Open `index.html` in a browser, or serve this directory with any static web server.

## GitHub Pages

1. Push the repository to GitHub.
2. Open **Settings → Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**.
4. Select the branch and `/ (root)` folder, then save.

No build step or framework is required. Update the enrollment and login links in `index.html` if the live portal URLs change.

## Files

- `index.html` — page structure, content and live DigiSwayam links
- `styles.css` — responsive design and styling
- `script.js` — mobile navigation
